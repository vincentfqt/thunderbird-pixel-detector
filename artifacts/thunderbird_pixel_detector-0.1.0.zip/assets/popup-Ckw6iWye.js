(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=document.querySelector(`#app`);if(!e)throw Error(`Élément #app introuvable`);e.innerHTML=`
  <header>
    <h1>Pixel Detector</h1>
    <p id="status">Extension chargée.</p>
  </header>

  <button id="analyze-button" type="button">
    Analyser le message
  </button>
`;var t=document.querySelector(`#analyze-button`),n=document.querySelector(`#status`);t?.addEventListener(`click`,async()=>{if(n)try{n.textContent=`Analyse en cours…`,n.textContent=(await messenger.runtime.sendMessage({type:`ANALYZE_CURRENT_MESSAGE`}))?.message??`Demande transmise au service d’analyse.`}catch(e){console.error(e),n.textContent=`Erreur pendant l’analyse.`}});